# 🧠 BRAIN BOOST GAME
*Train Your Brain, Challenge Your Mind!*

Offline-first Android brain-training game (package `com.brainboost.game`).
20 math & brain mini games · 500 tasks · 100 levels · coins · lucky spin · daily rewards · achievements · AdMob rewarded ads.

> Brain Boost Game is a practice/entertainment app. It makes **no** claim of increasing IQ or brain ability.

## Architecture
| Layer | What | Where |
|---|---|---|
| Native shell (Kotlin) | WebView host, **AdMob rewarded ads**, SharedPreferences backup of save data | `app/src/main/java/com/brainboost/game/MainActivity.kt` |
| Game (HTML/CSS/JS, 100% local) | UI, 20 games, coins, tasks, levels, spin, rewards | `app/src/main/assets/www/` |
| Question engine | Offline procedural question bank, every question validated before display | `www/questions.js` |

No remote API, server or online question loading. Only AdMob rewarded ads use the internet.

## 1. Open the project
Install **Android Studio (Koala or newer)** with JDK 17 (bundled). `File → Open` and choose this folder (the one containing `settings.gradle.kts`).

## 2. Import / Gradle sync
Android Studio syncs automatically (needs internet once to download Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 1.9.25, AdMob SDK 23.3.0). If it doesn't: `File → Sync Project with Gradle Files`. Install SDK Platform 35 if prompted.
If you want a `gradlew` script: run `gradle wrapper --gradle-version 8.9` once (the wrapper JAR is not bundled in this ZIP).

## 3. Build the APK
- **Debug (test ads):** `Build → Build Bundle(s) / APK(s) → Build APK(s)` → `app/build/outputs/apk/debug/app-debug.apk`
- **Release (real ads, signed):** `Build → Generate Signed Bundle / APK → APK`, create/select a keystore, choose **release**. Keep your keystore private (it is git-ignored).
- CLI: `./gradlew assembleDebug` / `./gradlew assembleRelease` (after creating the wrapper).

## 4. How AdMob works here
- Rewarded ads only. No banners, no forced interstitials; every ad starts from a button the player taps.
- The SDK lives in native code. JavaScript calls `Android.showRewardedAd(requestId)`; the reward is reported back **only** after AdMob's `OnUserEarnedRewardListener` fired *and* the ad was dismissed. Failed/not-ready/closed-early ads give nothing.
- Each request id is single-use, so a callback can't be replayed. A task can be doubled once (the pending reward is consumed).
- Ads preload and reload automatically (back-off retry). Offline → "Internet Required To Load Rewarded Ads." and the whole rest of the game keeps working.
- Used for: Task double coins · Extra lucky spins (max 5/day) · Reward Center bonus (max 10/day, `CFG.adEarnLimit`).

## 5. Test ads vs production ads
`app/build.gradle.kts` picks IDs per build type:
- **debug** → Google official test IDs (safe to click)
- **release** → your IDs: App ID `ca-app-pub-8610904151017465~5181735870`, Rewarded unit `ca-app-pub-8610904151017465/2618830913`

So production ads are only in release builds. **Never click your own real ads.** Add your own device as a test device in AdMob if you test release builds. If you publish in the EEA/UK, set up Google's consent message (UMP) in the AdMob console and add the UMP SDK before release.

## 6. Configuration
`www/app.js` → `CFG`: game unlock prices, daily rewards, wheel prizes + probability weights, free/ad spin counts, per-correct coin rewards, ad limits.

## 7. Upload to GitHub
```bash
cd BrainBoostGame
git init && git add . && git commit -m "Brain Boost Game"
git branch -M main
git remote add origin https://github.com/<you>/<repo>.git
git push -u origin main
```
(or create the repo on github.com and use "uploading an existing file").

## Features checklist
20 mini games (first 6 free, 7–20 unlockable at 500…6000 coins) · Easy/Medium/Hard/Expert · random, non-repeating validated questions · 500 tasks in 8 categories (each rewards once) · 100 levels (300, 500, 700 … rising cost) · coin ledger/history · daily reward + streak · spin wheel (5 free + 5 ad spins/day, weighted random) · achievements · profile & stats · settings (sound, music, vibration, dark mode, English/اردو for main labels, reset with confirmation) · first-launch welcome, name, tutorial.

## Notes
- Save data: WebView `localStorage`, mirrored into native SharedPreferences. Coins can't go negative and every transaction is logged.
- Sounds are synthesised in-app (WebAudio) – no external files. Icons are emoji/vector, fonts are system fonts, so nothing loads from the network.
- Rewarded-ad verification is client-side (AdMob SDK callback). Server-side verification would need a backend and is intentionally not used to stay offline-first.
