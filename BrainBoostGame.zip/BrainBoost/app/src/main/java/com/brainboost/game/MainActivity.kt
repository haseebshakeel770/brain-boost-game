package com.brainboost.game

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Brain Boost Game - native shell.
 * The whole game (UI + logic + question bank) lives in assets/www and runs offline.
 * Rewarded ads are handled ONLY here in native code. JavaScript can never fabricate a
 * reward: it receives a result only after AdMob's OnUserEarnedReward callback fired.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var rewarded: RewardedAd? = null
    private var loadingAd = false
    private var retry = 0
    private val handler = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
        }
        web.setBackgroundColor(0xFF0B1030.toInt())

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != "appassets.androidplatform.net"
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.bbBack&&window.bbBack())?'1':'0'") { r ->
                    if (r != "\"1\"") finish()
                }
            }
        })

        // Ads are optional: if SDK init or load fails, the rest of the game keeps working.
        try {
            MobileAds.initialize(this) { loadAd() }
        } catch (_: Throwable) { }
    }

    private fun loadAd() {
        if (loadingAd || rewarded != null) return
        loadingAd = true
        try {
            RewardedAd.load(this, BuildConfig.REWARDED_ID, AdRequest.Builder().build(),
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        rewarded = ad; loadingAd = false; retry = 0
                    }
                    override fun onAdFailedToLoad(e: LoadAdError) {
                        rewarded = null; loadingAd = false
                        retry = minOf(retry + 1, 6)
                        handler.postDelayed({ loadAd() }, 5000L * retry)
                    }
                })
        } catch (_: Throwable) { loadingAd = false }
    }

    private fun report(id: String, ok: Boolean, why: String) {
        runOnUiThread {
            web.evaluateJavascript("window.onAdResult&&window.onAdResult('$id',$ok,'$why')", null)
        }
    }

    private fun online(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    inner class Bridge {
        @JavascriptInterface fun isOnline(): Boolean = online()
        @JavascriptInterface fun isAdReady(): Boolean = rewarded != null
        @JavascriptInterface fun saveState(json: String) {
            getSharedPreferences("bb", MODE_PRIVATE).edit().putString("state", json).apply()
        }
        @JavascriptInterface fun loadState(): String =
            getSharedPreferences("bb", MODE_PRIVATE).getString("state", "") ?: ""

        @JavascriptInterface fun showRewardedAd(requestId: String) {
            val id = requestId.filter { it.isLetterOrDigit() }
            runOnUiThread {
                val ad = rewarded
                if (ad == null) { report(id, false, "not_ready"); loadAd(); return@runOnUiThread }
                var earned = false
                ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        rewarded = null; loadAd()
                        report(id, earned, if (earned) "ok" else "closed_early")
                    }
                    override fun onAdFailedToShowFullScreenContent(e: AdError) {
                        rewarded = null; loadAd(); report(id, false, "failed")
                    }
                }
                ad.show(this@MainActivity) { earned = true }   // OnUserEarnedRewardListener
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        web.destroy()
        super.onDestroy()
    }
}
