'use strict';
/* Offline question engine: every question is generated locally and validated before use. */
const QB={level:1};
const R=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const pick=a=>a[R(0,a.length-1)];
const shuf=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=R(0,i);[a[i],a[j]]=[a[j],a[i]]}return a};
const mag=d=>Math.round([10,25,60,150][d]*(1+(QB.level-1)*0.05));
const mm=d=>[5,9,12,15][d]+Math.floor(QB.level/10);

function numOpts(ans,spread){
  spread=Math.max(3,Math.round(spread));const s=new Set([ans]);let g=0;
  while(s.size<4){let v=ans+R(1,spread)*(Math.random()<.5?-1:1);if(++g>40)v=ans+s.size*7+g;if(v!==ans&&(ans<0||v>=0))s.add(v)}
  return shuf([...s]);
}
function mc(q,ans,spread){const o=numOpts(ans,spread);return{k:'mc',q,o:o.map(String),a:o.indexOf(ans)}}
function strOpts(ans,pool){const s=new Set([ans]);const p=shuf(pool);for(const x of p){if(s.size>=4)break;s.add(x)}const o=shuf([...s]);return{o,a:o.indexOf(ans)}}

function expr(d){
  const m=mag(d),x=mm(d);const o=pick(d===0?['+','−']:['+','−','×','÷']);let a,b,v;
  if(o==='+'){a=R(2,m);b=R(2,m);v=a+b}
  else if(o==='−'){a=R(3,m*2);b=R(2,a-1);v=a-b}
  else if(o==='×'){a=R(2,x);b=R(2,x);v=a*b}
  else{b=R(2,x);v=R(2,x);a=b*v}
  return{t:`${a} ${o} ${b}`,v,o,a,b};
}
const spreadOf=v=>Math.max(4,Math.round(Math.abs(v)/6));
function gAdd(d){const m=mag(d),a=R(2,m),b=R(2,m);return mc(`${a} + ${b}`,a+b,Math.max(5,m/5))}
function gSub(d){const m=mag(d),a=R(3,m*2),b=R(2,a-1);return mc(`${a} − ${b}`,a-b,Math.max(5,m/5))}
function gMul(d){const x=mm(d),a=R(2,x),b=R(2,x+(d>1?4:0));return mc(`${a} × ${b}`,a*b,Math.max(4,a+b))}
function gDiv(d){const x=mm(d),b=R(2,x),q=R(2,x+(d>1?5:0));return mc(`${b*q} ÷ ${b}`,q,Math.max(3,Math.round(q/3)))}
function gQuick(d){const e=expr(d);return mc(e.t,e.v,spreadOf(e.v))}
function gBlast(d){
  const a=R(2,Math.min(mag(d),30)),b=R(2,12),c=R(2,12),t=R(0,2);
  if(t===0)return mc(`${a} + ${b} × ${c}`,a+b*c,Math.max(5,b));
  if(t===1)return mc(`(${a} + ${b}) × ${c}`,(a+b)*c,Math.max(5,c*2));
  return mc(`${a*c} ÷ ${c} + ${b}`,a+b,Math.max(4,b));
}
function gFast(d){return Math.random()<.5?gBlast(d):gQuick(d)}

function gNumMem(d){
  const len=3+d+Math.floor(QB.level/25)+R(0,1);let s='';
  for(let i=0;i<len;i++)s+=i?R(0,9):R(1,9);
  return{k:'mem',q:'Memorize the number, then type it',show:s,ms:900+len*550,a:s};
}
function mkSeq(d,n){
  const t=d===0?0:d===1?pick([0,0,1]):d===2?pick([1,2,3]):pick([2,3,4,5]);const a=[];
  if(t===0){const s=R(1,20),st=R(2,6+QB.level%5);for(let i=0;i<n;i++)a.push(s+i*st)}
  else if(t===1){const r=pick([2,3]);let v=R(1,4);for(let i=0;i<n;i++){a.push(v);v*=r}}
  else if(t===2){const o=R(1,6);for(let i=0;i<n;i++)a.push((i+o)**2)}
  else if(t===3){let x=R(1,5),y=R(1,5);for(let i=0;i<n;i++){a.push(x);const z=x+y;x=y;y=z}}
  else if(t===4){let v=R(1,5),dd=R(1,3);const k=R(1,3);for(let i=0;i<n;i++){a.push(v);v+=dd;dd+=k}}
  else{let v=R(1,6);for(let i=0;i<n;i++){a.push(v);v=v*2+1}}
  return a;
}
function gSeq(d){const a=mkSeq(d,6);return mc(a.slice(0,5).join(', ')+', ?',a[5],spreadOf(a[5]))}
function gMissing(d){
  const a=mkSeq(d,6),h=R(1,4),ans=a[h];const txt=a.map((v,i)=>i===h?'__':v).join(', ');
  return mc(txt+'  → find __',ans,spreadOf(ans));
}
function gPattern(d){
  if(Math.random()<.5){
    const c=[R(1,9),R(1,9),R(1,9)];if(c[0]===c[1])c[1]=(c[1]%9)+1;
    const seq=[];for(let i=0;i<7+d;i++)seq.push(c[i%3]);const ans=c[(7+d)%3];
    return mc(seq.join(', ')+', ?',ans,4);
  }
  const s=R(2,15+d*10),a=R(2,5+d*3),b=R(1,a-1);const v=[s];
  for(let i=1;i<6;i++)v.push(v[i-1]+(i%2?a:-b));
  return mc(v.slice(0,5).join(', ')+', ?  (pattern: +'+a+', −'+b+')',v[5],Math.max(4,a));
}
function gOdd(d){
  const P=n=>{if(n<2)return false;for(let i=2;i*i<=n;i++)if(n%i===0)return false;return true};
  for(let tries=0;tries<200;tries++){
    const t=R(0,d>=2?4:3),m=mag(d);let gen,bad;
    if(t===0){gen=()=>2*R(1,m);bad=()=>2*R(0,m)+1}
    else if(t===1){const k=R(3,6+d);gen=()=>k*R(1,m);bad=()=>{let v;do v=R(2,k*m);while(v%k===0);return v}}
    else if(t===2){const mx=Math.max(4,Math.ceil(Math.sqrt(m*3)));gen=()=>R(1,mx)**2;bad=()=>{let v;do v=R(2,mx*mx);while(Number.isInteger(Math.sqrt(v)));return v}}
    else if(t===3){gen=()=>2*R(0,m)+1;bad=()=>2*R(1,m)}
    else{gen=()=>{let v;do v=R(4,m*4);while(P(v));return v};bad=()=>{let v;do v=R(2,m*4);while(!P(v));return v}}
    const g=new Set();let c=0;while(g.size<3&&c++<60)g.add(gen());if(g.size<3)continue;
    const b=bad();if(g.has(b))continue;const arr=shuf([...g,b]);
    return{k:'mc',q:'Which number does NOT belong with the others?',o:arr.map(String),a:arr.indexOf(b)};
  }
  return gAdd(d);
}
function gPuzzle(d){
  const m=Math.max(8,Math.round(mag(d)/2)),x=R(2,m),t=R(0,d>1?5:4);let q,a;
  if(t===0){const k=R(2,20);q=`I think of a number and add ${k}. The result is ${x+k}. What is my number?`;a=x}
  else if(t===1){const k=R(1,Math.min(15,2*x-1));q=`Double a number, then subtract ${k}, and you get ${2*x-k}. What is the number?`;a=x}
  else if(t===2){q=`Three equal numbers add up to ${3*x}. What is each number?`;a=x}
  else if(t===3){q=`The sum of two consecutive numbers is ${2*x+1}. What is the smaller number?`;a=x}
  else if(t===4){const p=R(2,9),k=R(2,9);q=`${p} boxes hold ${k} pencils each, and ${x} loose pencils are added. How many pencils in total?`;a=p*k+x}
  else{const k=R(2,5);q=`A number multiplied by ${k} and then increased by ${x} equals ${x*k*k+x}. What is the number?`;a=x*k}
  return mc(q,a,Math.max(4,Math.round(a/4)));
}
function gFlash(d){
  const n=3+d,s=new Set();while(s.size<n)s.add(R(10,99));const arr=[...s];
  const tgt=pick(arr),o=new Set([tgt]);while(o.size<4){const v=R(10,99);if(!s.has(v))o.add(v)}
  const opts=shuf([...o]);
  return{k:'flash',q:'Which number was shown?',show:arr.join('   '),ms:1400+n*450,o:opts.map(String),a:opts.indexOf(tgt)};
}
function gFocus(d){
  const size=[9,12,16,20][d],cols=[3,4,4,5][d],cells=new Set();
  const tgt=R(10,99);cells.add(tgt);
  while(cells.size<size){let v=R(10,99);if(d>=2&&Math.random()<.5){const t=String(tgt);v=Number(t[1]+t[0]);if(v<10||cells.has(v))v=R(10,99)}cells.add(v)}
  const arr=shuf([...cells]);return{k:'grid',q:`Find the number ${tgt}`,cells:arr,cols,a:arr.indexOf(tgt)};
}
const NAMES=['Ali','Sara','Omar','Zain','Hina','Bilal','Ayesha','Hamza','Noor','Fatima'];
const DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const LET='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
function gLogic(d){
  const t=R(0,4);
  if(t===0){const n=shuf(NAMES).slice(0,4),adj=pick([['taller','shortest'],['older','youngest'],['faster','slowest']]);
    const o=shuf(n);return{k:'mc',q:`${n[0]} is ${adj[0]} than ${n[1]}. ${n[1]} is ${adj[0]} than ${n[2]}. Who is the ${adj[1]} of these three?`,o,a:o.indexOf(n[2])}}
  if(t===1){const i=R(0,6),N=R(2,20+d*30),ans=DAYS[(i+N)%7];const r=strOpts(ans,DAYS);
    return{k:'mc',q:`Today is ${DAYS[i]}. What day will it be after ${N} days?`,o:r.o,a:r.a}}
  if(t===2){const N=3*R(2,10+d*10);return mc(`I have ${N} apples and give away one third of them. How many are left?`,N*2/3,Math.max(3,Math.round(N/6)))}
  if(t===3){const k=R(2,6),u=R(2,9+d*3),m=R(k+1,k+8);return mc(`${k} pens cost ${k*u} coins. How much do ${m} pens cost?`,m*u,Math.max(4,u*2))}
  const st=R(1,3),s0=R(0,10),seq=[0,1,2,3].map(i=>LET[s0+i*st]),ans=LET[s0+4*st];
  if(!ans||seq.some(x=>!x))return gLogic(d);
  const r=strOpts(ans,LET.split(''));return{k:'mc',q:`What comes next?  ${seq.join(', ')}, ?`,o:r.o,a:r.a};
}
function gSymbol(d){
  for(let i=0;i<200;i++){
    const m=Math.min(mag(d),40),a=R(2,m),b=R(2,Math.min(m,12)),ops=['+','−','×','÷'];
    const r=[a+b,a-b,a*b,a%b===0?a/b:null],k=R(0,d===0?1:3);
    if(r[k]===null||r[k]<0||r.filter(v=>v===r[k]).length>1)continue;
    return{k:'mc',q:`${a}  ?  ${b}  =  ${r[k]}`,o:ops,a:k};
  }
  return gAdd(d);
}
function gTF(d){
  const e=expr(d),right=Math.random()<.5;let shown=e.v;
  if(!right){do shown=e.v+pick([-10,-3,-2,-1,1,2,3,10]);while(shown<0||shown===e.v)}
  return{k:'mc',q:`${e.t} = ${shown}`,o:['True','False'],a:right?0:1};
}
function gCmp(d){
  const big=Math.random()<.5;let A,B,va,vb;
  do{
    if(d===0){va=R(1,mag(d)*3);vb=R(1,mag(d)*3);A=String(va);B=String(vb)}
    else{const e=expr(d);va=e.v;A=e.t;if(Math.random()<.5){const f=expr(d);vb=f.v;B=f.t}else{vb=Math.max(1,va+R(-6,6));B=String(vb)}}
  }while(va===vb);
  const ans=big?(va>vb?0:1):(va<vb?0:1);
  return{k:'mc',q:big?'Which is LARGER?':'Which is SMALLER?',o:[A,B],a:ans};
}
const GAMES=[
{id:1,n:'Quick Math',i:'⚡',c:'Math',g:gQuick,tm:1,desc:'Add, subtract, multiply & divide against the clock'},
{id:2,n:'Math Blast',i:'💥',c:'Speed',g:gBlast,tm:.9,desc:'Fast multi-step questions, pick the right answer'},
{id:3,n:'Number Memory',i:'🧠',c:'Memory',g:gNumMem,tm:1.4,desc:'Memorize the digits, then type them back'},
{id:4,n:'Missing Number',i:'🔍',c:'Logic',g:gMissing,tm:1.2,desc:'Find the missing number in a series'},
{id:5,n:'Number Sequence',i:'🔢',c:'Logic',g:gSeq,tm:1.2,desc:'What comes next in the sequence?'},
{id:6,n:'Multiplication Master',i:'✖️',c:'Math',g:gMul,tm:1,desc:'Times-table training at every difficulty'},
{id:7,n:'Division Challenge',i:'➗',c:'Math',g:gDiv,tm:1,desc:'Exact division puzzles'},
{id:8,n:'Addition Master',i:'➕',c:'Math',g:gAdd,tm:.9,desc:'Rapid addition drills'},
{id:9,n:'Subtraction Pro',i:'➖',c:'Math',g:gSub,tm:.9,desc:'Subtraction challenges'},
{id:10,n:'Find The Odd One',i:'🎯',c:'Focus',g:gOdd,tm:1.2,desc:'Spot the number that does not belong'},
{id:11,n:'Math Puzzle',i:'🧩',c:'Math',g:gPuzzle,tm:1.8,desc:'Word puzzles with hidden numbers'},
{id:12,n:'Number Pattern',i:'🌀',c:'Logic',g:gPattern,tm:1.3,desc:'Discover the pattern between numbers'},
{id:13,n:'Memory Flash',i:'📸',c:'Memory',g:gFlash,tm:1,desc:'Numbers flash briefly, pick what you saw'},
{id:14,n:'Focus Test',i:'👁️',c:'Focus',g:gFocus,tm:1.6,desc:'Find the target number in the grid'},
{id:15,n:'Fast Calculation',i:'🚀',c:'Speed',g:gFast,tm:.65,desc:'Solve as many as you can, very fast'},
{id:16,n:'Logic Master',i:'🧐',c:'Logic',g:gLogic,tm:2,desc:'Logic and reasoning problems'},
{id:17,n:'Missing Symbol',i:'❓',c:'Math',g:gSymbol,tm:1.1,desc:'Which operator completes the equation?'},
{id:18,n:'True Or False',i:'✅',c:'Speed',g:gTF,tm:.8,desc:'Is the equation correct?'},
{id:19,n:'Number Comparison',i:'⚖️',c:'Speed',g:gCmp,tm:.9,desc:'Choose the larger or smaller value'},
{id:20,n:'Brain Challenge',i:'🏆',c:'Logic',g:null,tm:1.3,desc:'Mixed challenge from every game'}
];
GAMES[19].g=function(d){const g=pick(GAMES.filter(x=>x.id!==20));const q=g.g(d);q.tag=g.n;q.tmMul=g.tm*1.1;return q};
const CATS=['All','Math','Memory','Focus','Logic','Speed'];

function validQ(q){
  if(!q||!q.k)return false;
  if(q.k==='mc'||q.k==='flash'){return Array.isArray(q.o)&&new Set(q.o).size===q.o.length&&Number.isInteger(q.a)&&q.a>=0&&q.a<q.o.length&&q.o.every(x=>x!==''&&!/NaN|Infinity|undefined/.test(x))&&!/NaN|Infinity|undefined/.test(q.q)}
  if(q.k==='mem')return /^[1-9]\d+$/.test(q.a)&&q.a===q.show;
  if(q.k==='grid')return new Set(q.cells).size===q.cells.length&&q.a>=0&&q.cells[q.a]!==undefined;
  return false;
}
function makeQ(game,d,recent){
  for(let i=0;i<40;i++){
    let q;try{q=game.g(d)}catch(e){continue}
    if(!validQ(q))continue;
    const key=game.id+'|'+q.q+'|'+(q.show||'')+(q.cells?q.cells.join():'');
    if(recent.includes(key))continue;
    recent.push(key);if(recent.length>12)recent.shift();
    q.tmMul=q.tmMul||game.tm;return q;
  }
  return gAdd(d);
}
