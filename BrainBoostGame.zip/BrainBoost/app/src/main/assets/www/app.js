'use strict';
/* Brain Boost Game - app logic (runs fully offline inside the Android WebView) */
const CFG={version:'1.0.0',roundQ:10,freeSpins:5,adSpins:5,adEarnCoins:50,adEarnLimit:10,
 daily:[50,75,100,150,200,300,500],
 unlock:{7:500,8:700,9:900,10:1200,11:1500,12:1800,13:2200,14:2600,15:3000,16:3500,17:4000,18:4500,19:5000,20:6000},
 wheel:[[10,22],[20,20],[30,16],[50,14],[75,10],[100,7],[150,5],[200,3],[300,2],[500,1]], // [coins, probability weight]
 perCorrect:[2,3,4,6],welcome:100};
const DIFF=['Easy','Medium','Hard','Expert'],MAXLV=100;
const $=s=>document.querySelector(s),p2=n=>String(n).padStart(2,'0');
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>Number(n).toLocaleString('en-US');
const dstr=(o=0)=>{const d=new Date();d.setDate(d.getDate()+o);return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())};
const I18={ur:{Home:'ہوم',Games:'گیمز',Tasks:'ٹاسکس',Rewards:'انعامات',Profile:'پروفائل','Welcome Back!':'خوش آمدید!','Ready To Boost Your Brain?':'کیا آپ دماغی ورزش کے لیے تیار ہیں؟',Coins:'کوائنز',Level:'لیول',Streak:'اسٹریک','Spin & Win':'اسپن اور جیتیں',Settings:'سیٹنگز','Daily Progress':'روزانہ پیش رفت','Daily Reward':'روزانہ انعام'}};
const T=k=>(S&&S.set.lang==='ur'&&I18.ur[k])||k;

/* ---------- state & storage ---------- */
let S=null;
const def=()=>({name:'Player',coins:0,xp:0,level:1,lvUnlocked:[1],gUnlocked:[1,2,3,4,5,6],done:{},pending:null,claimed:{},
 stats:{played:0,correct:0,wrong:0,best:0,sec:0,earned:0,tasks:0},pg:{},daily:{last:'',streak:0},spin:{d:'',free:0,ad:0,extra:0},
 adEarn:{d:'',n:0},today:{d:'',games:0},hist:[],set:{sound:1,music:0,vib:1,theme:'dark',lang:'en'},onboarded:0});
function load(){
  let raw=null;try{raw=localStorage.getItem('bb_state')}catch(e){}
  if(!raw&&window.Android){try{raw=Android.loadState()}catch(e){}}
  let d=null;try{d=raw?JSON.parse(raw):null}catch(e){}
  const b=def();S=Object.assign(b,d&&typeof d==='object'?d:{});
  for(const k of ['stats','set','daily','spin','adEarn','today'])S[k]=Object.assign(b[k],S[k]||{});
  S.coins=Math.max(0,Math.floor(+S.coins||0));S.level=Math.min(MAXLV,Math.max(1,Math.floor(+S.level||1)));
  if(!Array.isArray(S.lvUnlocked)||!S.lvUnlocked.includes(1))S.lvUnlocked=[1];
  if(!S.lvUnlocked.includes(S.level))S.level=1;
  S.gUnlocked=[...new Set([1,2,3,4,5,6,...(Array.isArray(S.gUnlocked)?S.gUnlocked:[])])].filter(x=>x>=1&&x<=20);
  if(!Array.isArray(S.hist))S.hist=[];
}
function save(){const j=JSON.stringify(S);try{localStorage.setItem('bb_state',j)}catch(e){}if(window.Android){try{Android.saveState(j)}catch(e){}}}
function logTx(n,why){S.hist.unshift({a:n,w:why,t:Date.now(),b:S.coins});if(S.hist.length>500)S.hist.length=500;if(n>0)S.stats.earned+=n}
function addCoins(n,why){n=Math.floor(n);if(!(n>0)||!isFinite(n))return false;S.coins+=n;logTx(n,why);save();syncCoin();return true}
function spend(n,why){n=Math.floor(n);if(!(n>0)||S.coins<n)return false;S.coins-=n;logTx(-n,why);save();syncCoin();return true}
function syncCoin(){document.querySelectorAll('.cv').forEach(e=>e.textContent=fmt(S.coins))}
function rollDay(){const t=dstr();if(S.today.d!==t)S.today={d:t,games:0};if(S.spin.d!==t)S.spin={d:t,free:0,ad:0,extra:0};if(S.adEarn.d!==t)S.adEarn={d:t,n:0}}

/* ---------- sound (synthesised locally with WebAudio, no external files) ---------- */
let ac=null,musicT=null;
function AC(){if(!ac){try{ac=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(ac&&ac.state==='suspended')ac.resume();return ac}
function tone(f,d=.12,ty='sine',v=.15,dl=0,m=0){if(!(m?S.set.music:S.set.sound))return;const a=AC();if(!a)return;const o=a.createOscillator(),g=a.createGain(),t=a.currentTime+dl;o.type=ty;o.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(a.destination);o.start(t);o.stop(t+d+.02)}
const SFX={click:()=>tone(520,.05,'triangle',.08),ok:()=>{tone(660,.1);tone(880,.15,'sine',.15,.09)},bad:()=>tone(180,.28,'sawtooth',.1),
 coin:()=>{tone(988,.08,'square',.05);tone(1319,.2,'square',.05,.08)},unlock:()=>[523,659,784,1047].forEach((f,i)=>tone(f,.18,'triangle',.12,i*.09)),
 tick:()=>tone(900,.03,'square',.03),win:()=>[523,659,784,659,784,1047].forEach((f,i)=>tone(f,.2,'triangle',.12,i*.12))};
const sfx=n=>{try{SFX[n]()}catch(e){}};
const buzz=ms=>{if(S.set.vib&&navigator.vibrate)try{navigator.vibrate(ms)}catch(e){}};
function setMusic(){clearInterval(musicT);musicT=null;if(S.set.music&&!document.hidden){const sc=[262,294,330,392,440,392,330,294];let i=0;musicT=setInterval(()=>tone(sc[i++%8],.6,'sine',.03,0,1),650)}}
document.addEventListener('visibilitychange',setMusic);

/* ---------- ads (native AdMob bridge; reward only on verified native callback) ---------- */
let pendingAd=null,adTimer=null;
function watchAd(cb){
  if(pendingAd)return;
  if(!window.Android){toast('Rewarded ads work only inside the Android app.');return cb(false)}
  let on=true;try{on=Android.isOnline()}catch(e){}
  if(!on){msgModal('📡','No Internet','Internet Required To Load Rewarded Ads.');return cb(false)}
  const id='r'+Date.now().toString(36)+Math.random().toString(36).slice(2,8);
  pendingAd={id,cb};showLoader('Preparing ad…');
  clearTimeout(adTimer);adTimer=setTimeout(()=>{if(pendingAd&&pendingAd.id===id){const p=pendingAd;pendingAd=null;hideLoader();p.cb(false)}},120000);
  try{Android.showRewardedAd(id)}catch(e){window.onAdResult(id,false,'failed')}
}
window.onAdResult=(id,ok,why)=>{
  hideLoader();if(!pendingAd||pendingAd.id!==id)return;
  const p=pendingAd;pendingAd=null;clearTimeout(adTimer);
  if(!ok)toast(why==='not_ready'?'Ad is not ready yet. Please try again shortly.':'Ad not completed. No reward given.');
  p.cb(!!ok);
};

/* ---------- levels / tasks data ---------- */
const LVC=[0,0,300,500,700,1000,1300,1700,2200,2800,3500];
const lvCost=l=>l<LVC.length?LVC[l]:Math.round((3500+(l-10)*(450+(l-10)*12))/50)*50;
const TASKS=(()=>{
  const cats=[['Beginner Challenges',60,0,20,5,'🌱'],['Easy Challenges',80,0,30,10,'🙂'],['Medium Challenges',90,1,60,15,'💪'],['Hard Challenges',90,2,100,20,'🔥'],
   ['Expert Challenges',80,3,150,30,'👑'],['Daily Challenges',40,1,50,10,'📅'],['Special Challenges',30,2,120,20,'⭐'],['Mega Brain Challenges',30,3,250,50,'🚀']];
  const fixed=[20,30,40,50,60,80,100,120,150,200],out=[];let id=0;
  cats.forEach((c,ci)=>{for(let j=0;j<c[1];j++){out.push({id:id+1,ci,gid:(id*3+ci)%20+1,d:c[2],target:Math.min(10,[6,7,8,9][c[2]]+(j%3===2?1:0)),reward:id<10?fixed[id]:c[3]+(j%10)*c[4]});id++}});
  out.cats=cats;return out;
})();
const gameOf=id=>GAMES.find(g=>g.id===id);
const taskText=t=>`Score ${t.target}/${CFG.roundQ} in ${gameOf(t.gid).n} (${DIFF[t.d]})`;

/* ---------- achievements ---------- */
const mathCorrect=()=>GAMES.filter(g=>g.c==='Math').reduce((a,g)=>a+((S.pg[g.id]||{}).c||0),0);
const ACH=[
 ['first','First Game Completed','🎮',()=>S.stats.played,1,50],['g10','10 Games Completed','🎲',()=>S.stats.played,10,100],
 ['t50','50 Tasks Completed','✅',()=>S.stats.tasks,50,300],['t100','100 Tasks Completed','💯',()=>S.stats.tasks,100,600],
 ['c1k','1000 Coins Collected','🪙',()=>S.stats.earned,1000,100],['c5k','5000 Coins Collected','💰',()=>S.stats.earned,5000,300],
 ['l10','10 Levels Unlocked','🏅',()=>S.lvUnlocked.length,10,300],['s7','7 Days Streak','🔥',()=>S.daily.streak,7,200],
 ['math','Math Master (200 correct math answers)','➗',mathCorrect,200,250],
 ['mem','Memory Champion (100 correct memory answers)','🧠',()=>((S.pg[3]||{}).c||0)+((S.pg[13]||{}).c||0),100,250],
 ['exp','Brain Explorer (play 10 different games)','🧭',()=>Object.keys(S.pg).filter(k=>S.pg[k].p>0).length,10,200]];

/* ---------- UI helpers ---------- */
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2200)}
function showLoader(m){$('#loadmsg').textContent=m;$('#loader').classList.add('show')}
function hideLoader(){$('#loader').classList.remove('show')}
function modal(h){const m=$('#modal');m.innerHTML=`<div class="mod">${h}</div>`;m.classList.add('show')}
function closeModal(){const m=$('#modal');m.classList.remove('show');m.innerHTML=''}
function msgModal(ic,t,msg){modal(`<div class="big">${ic}</div><h2>${esc(t)}</h2><p style="margin:8px 0">${esc(msg)}</p><button class="btn" data-a="close">OK</button>`)}
function confetti(){const c=['#ffc933','#00d4ff','#7c3aed','#22c55e','#ef4444'];for(let i=0;i<40;i++){const e=document.createElement('i');e.className='cf';e.style.left=Math.random()*100+'vw';e.style.background=c[i%5];e.style.animationDelay=Math.random()*.8+'s';document.body.appendChild(e);setTimeout(()=>e.remove(),3800)}}

/* ---------- router ---------- */
const TABS=[['home','🏠','Home'],['games','🎮','Games'],['tasks','✅','Tasks'],['rewards','🎁','Rewards'],['profile','👤','Profile']];
const TITLES={games:'Games',tasks:'Tasks',rewards:'Reward Center',profile:'Profile',spin:'Spin & Win',daily:'Daily Reward',history:'Coin History',ach:'Achievements',stats:'Statistics',settings:'Settings',about:'About Game',privacy:'Privacy Policy',levels:'Levels',menu:'Menu',result:'Result'};
let cur='splash',param=null,stack=[],G=null,tick=null,taskCat=0,taskPage=1,gameCat='All';
function go(n,p,mode){
  clearInterval(tick);
  if(TABS.some(x=>x[0]===n)&&mode!=='replace')stack=[];
  else if(mode!=='replace'&&cur!==n&&!['splash','welcome','name','tut'].includes(cur))stack.push([cur,p===undefined?null:param]);
  cur=n;param=p;render();
}
function back(){
  if($('#modal').classList.contains('show')){if(!S.pending)closeModal();return true}
  if(cur==='play'){clearInterval(tick);const s=stack.pop();G=null;if(s){cur=s[0];param=null}else cur='games';render();return true}
  if(['splash','welcome','name','tut'].includes(cur))return true;
  if(stack.length){const s=stack.pop();cur=s[0];param=null;render();return true}
  if(cur!=='home'){go('home');return true}
  return false;
}
window.bbBack=back;
function render(){
  rollDay();document.body.dataset.theme=S.set.theme;
  document.documentElement.dir=S.set.lang==='ur'?'rtl':'ltr';
  const full=['welcome','name','tut','play'].includes(cur),isTab=TABS.some(x=>x[0]===cur);
  const top=$('#top'),nav=$('#nav'),view=$('#view');
  top.style.display=full?'none':'flex';nav.style.display=full?'none':'flex';
  top.innerHTML=(isTab?`<div class="ttl">🧠 <span>${cur==='home'?'BRAIN BOOST':T(TABS.find(x=>x[0]===cur)[2])}</span></div>`:`<button class="ib" data-a="back">←</button><div class="ttl">${T(TITLES[cur]||'')}</div>`)+
   `<button class="coin" data-a="go" data-p="history">🪙 <span class="cv">${fmt(S.coins)}</span></button><button class="ib" data-a="go" data-p="menu">☰</button>`;
  nav.innerHTML=TABS.map(t=>`<button data-a="go" data-p="${t[0]}" class="${cur===t[0]?'on':''}"><span>${t[1]}</span>${T(t[2])}</button>`).join('');
  view.innerHTML=(V[cur]||V.home)();view.scrollTop=0;view.style.animation='none';void view.offsetWidth;view.style.animation='';
  if(POST[cur])POST[cur]();
  if(S.pending&&!$('#modal').classList.contains('show')&&cur!=='play')taskModal();
}

/* ---------- views ---------- */
const V={};const POST={};
V.welcome=()=>`<div class="full"><div class="big">🧠</div><h1 style="font-size:30px">BRAIN BOOST GAME</h1><p>Train Your Brain, Challenge Your Mind!</p><p style="margin:14px 0">20 math & brain mini games, daily rewards, lucky spin and more — all offline.</p><button class="btn gold" data-a="toName">Get Started</button></div>`;
V.name=()=>`<div class="full"><div class="big">👋</div><h2>What should we call you?</h2><input id="nm" class="inp" maxlength="16" placeholder="Player name" value="${S.onboarded?esc(S.name):''}"><button class="btn" data-a="saveName">Continue</button></div>`;
const TUT=[['🎮','How to play','Pick a game, choose a difficulty and answer 10 questions. Each correct answer earns points and coins.'],['🪙','Earn coins','Complete tasks, play games, claim daily rewards and spin the lucky wheel.'],['🔓','Unlock levels & games','Spend coins to unlock new levels and the locked mini games. Unlocks are permanent.'],['🎡','Lucky Spin','You get 5 free spins every day. Watch a rewarded ad for up to 5 extra spins.'],['📺','Rewarded ads','After a task you can watch an optional ad to double your coins. Ads are always your choice.']];
V.tut=()=>{const i=param||0,t=TUT[i];return `<div class="full"><div class="big">${t[0]}</div><h2>${t[1]}</h2><p style="margin:8px 0 14px">${t[2]}</p><div class="dots">${TUT.map((_,k)=>`<i class="${k===i?'on':''}"></i>`).join('')}</div><button class="btn" data-a="tutNext" data-p="${i}">${i===TUT.length-1?'Start Playing':'Next'}</button><button class="btn ghost" data-a="tutSkip">Skip</button></div>`};

function taskRow(t){const g=gameOf(t.gid),dn=S.done[t.id];
  return `<div class="trow glass ${dn?'done':''}" data-a="startTask" data-p="${t.id}"><div class="ic">${g.i}</div><div class="gr"><b>#${t.id} ${esc(taskText(t))}</b><br><small>${TASKS.cats[t.ci][0]}</small></div><div>${dn?'<span class="tag done">Completed ✔</span>':`<span class="tag">🪙 ${t.reward}</span>`}</div></div>`}
function dailyTasks(){const ds=TASKS.filter(t=>t.ci===5);const off=Math.floor(Date.now()/864e5)%ds.length,out=[];for(let i=0;i<ds.length&&out.length<3;i++){const t=ds[(off+i)%ds.length];if(!S.done[t.id])out.push(t)}return out}
V.home=()=>{
  const g=S.today.games,pr=Math.min(100,Math.round(g/3*100)),st=S.daily.streak;
  const feat=GAMES.slice(0,6).concat(GAMES.filter(x=>S.gUnlocked.includes(x.id)&&x.id>6)).slice(0,8);
  return `<section class="hero glass"><div class="hello"><div class="av">${esc((S.name[0]||'P').toUpperCase())}</div><div><h2>${T('Welcome Back!')}</h2><p>${T('Ready To Boost Your Brain?')}</p><small>👤 ${esc(S.name)}</small></div></div></section>
  <div class="stats"><div class="stat glass"><b>🪙 <span class="cv">${fmt(S.coins)}</span></b><small>${T('Coins')}</small></div><div class="stat glass" data-a="go" data-p="levels"><b>Lv ${S.level}</b><small>${T('Level')}</small></div>
  <div class="stat glass"><b>${S.stats.tasks}</b><small>Completed Tasks</small></div><div class="stat glass" data-a="go" data-p="daily"><b>🔥 ${st}</b><small>${T('Streak')}</small></div></div>
  <div class="glass card"><div class="row"><b>${T('Daily Progress')}</b><span>${Math.min(g,3)}/3 games</span></div><div class="bar" style="margin-top:8px"><i style="width:${pr}%"></i></div></div>
  <div class="quick"><button data-a="go" data-p="spin"><span>🎡</span>${T('Spin & Win')}</button><button data-a="go" data-p="daily"><span>📅</span>${T('Daily Reward')}</button><button data-a="go" data-p="rewards"><span>🎁</span>Reward Center</button></div>
  <div class="sec">Daily Challenges <button class="btn sm ghost" data-a="go" data-p="tasks">All</button></div>${dailyTasks().map(taskRow).join('')||'<p class="card">All daily challenges done! 🎉</p>'}
  <div class="sec">Game Categories</div><div class="chips">${CATS.slice(1).map(c=>`<button class="chip" data-a="catGo" data-p="${c}">${c}</button>`).join('')}</div>
  <div class="sec">Available Games</div><div class="grid2">${feat.map(gameCard).join('')}</div>`};
function gameCard(g){const un=S.gUnlocked.includes(g.id),pr=CFG.unlock[g.id];
  return `<div class="gc glass ${un?'':'lock'}" data-a="openGame" data-p="${g.id}">${un?'':'<span class="lk">🔒</span>'}<div class="ic">${g.i}</div><b>${g.n}</b><small>${g.c}</small><br>${un?(g.id<=6?'<span class="tag free">FREE</span>':'<span class="tag free">UNLOCKED</span>'):`<span class="tag">🪙 ${fmt(pr)}</span>`}</div>`}
V.games=()=>`<div class="chips">${CATS.map(c=>`<button class="chip ${c===gameCat?'on':''}" data-a="catSet" data-p="${c}">${c}</button>`).join('')}</div><div class="grid2">${GAMES.filter(g=>gameCat==='All'||g.c===gameCat).map(gameCard).join('')}</div>`;
V.tasks=()=>{const list=TASKS.filter(t=>t.ci===taskCat),shown=list.slice(0,taskPage*25),dn=list.filter(t=>S.done[t.id]).length;
  return `<div class="chips">${TASKS.cats.map((c,i)=>`<button class="chip ${i===taskCat?'on':''}" data-a="taskCat" data-p="${i}">${c[5]} ${c[0].replace(' Challenges','')}</button>`).join('')}</div>
  <div class="glass card"><div class="row"><b>${TASKS.cats[taskCat][0]}</b><span class="pill">${dn}/${list.length}</span></div><div class="bar" style="margin-top:8px"><i style="width:${dn/list.length*100}%"></i></div></div>
  ${shown.map(taskRow).join('')}${shown.length<list.length?'<button class="btn ghost" data-a="moreTasks">Show more</button>':''}<p style="text-align:center;margin-top:10px">Total tasks: ${TASKS.length} • each task rewards coins only once</p>`};
V.rewards=()=>{rollDay();const left=CFG.adEarnLimit-S.adEarn.n,sp=(CFG.freeSpins-S.spin.free)+S.spin.extra;
  const item=(ic,t,d,r,a,p='')=>`<button class="li glass" data-a="${a}" data-p="${p}"><span class="ic">${ic}</span><span class="gr"><b>${t}</b><br><small>${d}</small></span><span class="tag">${r}</span></button>`;
  return `<div class="glass card" style="text-align:center"><small>Your balance</small><h1 style="font-size:38px">🪙 <span class="cv">${fmt(S.coins)}</span></h1></div><div class="list">
  ${item('📺','Watch Rewarded Ad & Earn Coins',`${left} ads left today`,'+'+CFG.adEarnCoins,'adEarn')}
  ${item('✨','Double Your Task Rewards','Finish a task, then watch an ad','x2','go','tasks')}
  ${item('🎡','Spin & Win',`${sp} spins available`,'up to 500','go','spin')}
  ${item('📅','Complete Daily Challenges','3 fresh challenges each day','50+','go','tasks')}
  ${item('🧠','Complete Brain Tasks',`${TASKS.length} tasks`,'20–450','go','tasks')}
  ${item('🎁','Daily Login Reward','7-day streak rewards','50–500','go','daily')}</div><p style="text-align:center">Ads need internet and are always optional.</p>`};
V.profile=()=>{const s=S.stats,m=Math.floor(s.sec/60);
  const cell=(a,b)=>`<div class="stat glass"><b>${a}</b><small>${b}</small></div>`;
  return `<div class="glass card hero" style="text-align:center"><div class="av" style="margin:auto">${esc((S.name[0]||'P').toUpperCase())}</div><h2 style="margin-top:8px">${esc(S.name)}</h2><button class="btn sm ghost" style="margin-top:8px" data-a="editName">✏️ Change name</button></div>
  <div class="stats">${cell('🪙 '+fmt(S.coins),'Total Coins')}${cell(S.level,'Current Level')}${cell(fmt(S.xp),'Total XP')}${cell(s.played,'Games Played')}${cell(s.tasks,'Tasks Completed')}${cell(fmt(s.correct),'Correct Answers')}${cell(fmt(s.wrong),'Wrong Answers')}${cell(fmt(s.best),'Best Score')}${cell('🔥 '+S.daily.streak,'Daily Streak')}${cell(m>=60?Math.floor(m/60)+'h '+m%60+'m':m+'m','Total Play Time')}${cell(S.gUnlocked.length+'/20','Unlocked Games')}${cell(S.lvUnlocked.length+'/'+MAXLV,'Unlocked Levels')}</div>
  <button class="btn" data-a="go" data-p="levels">Levels</button><button class="btn ghost" data-a="go" data-p="ach">Achievements</button>`};
V.menu=()=>{const it=[['📅','Daily Rewards','daily'],['🎡','Lucky Spin','spin'],['📜','Coin History','history'],['🏆','Achievements','ach'],['📊','Statistics','stats'],['🔢','Levels','levels'],['⚙️','Settings','settings'],['ℹ️','About Game','about'],['🔒','Privacy Policy','privacy']];
  return `<div class="list">${it.map(i=>`<button class="li glass" data-a="go" data-p="${i[2]}"><span class="ic">${i[0]}</span><span class="gr"><b>${i[1]}</b></span><span>›</span></button>`).join('')}</div>`};
V.history=()=>S.hist.length?`<div class="glass card"><div class="row"><b>Current Balance</b><span class="coin">🪙 <span class="cv">${fmt(S.coins)}</span></span></div></div><div class="list">${S.hist.map(h=>{const d=new Date(h.t);return `<div class="li glass"><span class="gr"><b>${esc(h.w)}</b><br><small>${d.toLocaleDateString()} ${p2(d.getHours())}:${p2(d.getMinutes())}</small></span><span class="${h.a>0?'plus':'minus'}">${h.a>0?'+':''}${fmt(h.a)}</span></div>`}).join('')}</div>`:'<div class="full"><div class="big">📜</div><p>No transactions yet.</p></div>';
V.ach=()=>`<div class="list">${ACH.map(a=>{const cur=Math.min(a[3](),a[4]),ok=cur>=a[4],cl=S.claimed[a[0]];
  return `<div class="li glass"><span class="ic">${a[2]}</span><span class="gr"><b>${a[1]}</b><div class="bar" style="margin:6px 0 4px"><i style="width:${cur/a[4]*100}%"></i></div><small>${fmt(cur)}/${fmt(a[4])} • reward 🪙 ${a[5]}</small></span>${cl?'<span class="tag done">Claimed</span>':`<button class="btn sm ${ok?'gold':'ghost dis'}" data-a="claimAch" data-p="${a[0]}">Claim</button>`}</div>`}).join('')}</div>`;
V.stats=()=>{const s=S.stats,tot=s.correct+s.wrong,acc=tot?Math.round(s.correct/tot*100):0;
  return `<div class="stats"><div class="stat glass"><b>${acc}%</b><small>Accuracy</small></div><div class="stat glass"><b>${fmt(s.earned)}</b><small>Total coins earned</small></div><div class="stat glass"><b>${s.played}</b><small>Games played</small></div><div class="stat glass"><b>${fmt(s.best)}</b><small>Best score</small></div></div>
  <div class="sec">Per game</div><div class="list">${GAMES.map(g=>{const p=S.pg[g.id]||{p:0,c:0,w:0};return `<div class="li glass"><span class="ic">${g.i}</span><span class="gr"><b>${g.n}</b><br><small>${p.p} played • ✔ ${p.c} • ✘ ${p.w}</small></span></div>`}).join('')}</div>`};
V.about=()=>`<div class="glass card" style="text-align:center"><div class="big">🧠</div><h2>BRAIN BOOST GAME</h2><p>Train Your Brain, Challenge Your Mind!</p><p style="margin-top:8px">Version ${CFG.version}</p></div><div class="glass card"><p class="txt">Brain Boost Game is a collection of 20 math and brain-training mini games for mental calculation, memory, focus, logic and reaction practice.\n\nIt is a practice and entertainment app. It does not claim to measure or increase IQ or brain ability.\n\nEverything works offline. Only optional rewarded ads need an internet connection.</p></div>`;
V.privacy=()=>`<div class="glass card"><p class="txt"><b>Privacy Policy</b>\n\nBrain Boost Game stores your name, coins, progress and settings only on your own device. We do not run any server and do not collect, upload or sell your personal data.\n\nRewarded ads are provided by Google AdMob. AdMob may use your device advertising ID and similar technical information to serve and measure ads, as described in Google's own privacy policy. Ads load only when you choose to watch one.\n\nYou can erase all game data at any time in Settings → Reset Game Data, or by uninstalling the app.</p></div>`;
V.settings=()=>{const tg=(k,l)=>`<button class="li glass" data-a="tog" data-p="${k}"><span class="gr"><b>${l}</b></span><span class="tg ${S.set[k]?'on':''}"></span></button>`;
  return `<div class="list">${tg('sound','🔊 Sound')}${tg('music','🎵 Music')}${tg('vib','📳 Vibration')}
  <button class="li glass" data-a="theme"><span class="gr"><b>🌙 Dark Mode</b></span><span class="tg ${S.set.theme==='dark'?'on':''}"></span></button>
  <button class="li glass" data-a="lang"><span class="gr"><b>🌐 Language</b></span><span class="pill">${S.set.lang==='ur'?'اردو':'English'}</span></button>
  <button class="li glass" data-a="go" data-p="privacy"><span class="gr"><b>🔒 Privacy Policy</b></span>›</button>
  <button class="li glass" data-a="go" data-p="about"><span class="gr"><b>ℹ️ About App</b></span>›</button>
  <div class="li glass"><span class="gr"><b>Version</b></span><span>${CFG.version}</span></div>
  <button class="li glass" data-a="resetAsk"><span class="gr"><b style="color:var(--no)">🗑 Reset Game Data</b></span>›</button></div>`};

/* daily reward */
function dailyState(){const d=S.daily,t=dstr();if(d.last===t)return{claimed:true,idx:(d.streak-1)%7};const s=d.last===dstr(-1)?d.streak+1:1;return{claimed:false,idx:(s-1)%7,next:s}}
V.daily=()=>{const st=dailyState();
  return `<div class="glass card hero" style="text-align:center"><div class="big">🔥</div><h2>${S.daily.streak} day streak</h2><p>${st.claimed?'Come back tomorrow for the next reward!':'Your reward is ready!'}</p></div>
  <div class="days">${CFG.daily.map((c,i)=>{const got=st.claimed?i<=st.idx:i<st.idx,nx=!st.claimed&&i===st.idx;return `<div class="day ${got?'got':''} ${nx?'nxt':''} ${i===6?'d7':''}">${i===6?'⭐ Day 7 Special':'Day '+(i+1)}<b>🪙 ${c}</b>${got?'✔':''}</div>`}).join('')}</div>
  <button class="btn gold ${st.claimed?'dis':''}" data-a="claimDaily">${st.claimed?'Claimed Today ✔':'Claim Today\'s Reward'}</button>`};

/* levels */
V.levels=()=>{const hi=Math.max(...S.lvUnlocked),nx=hi+1;
  return `<div class="glass card"><div class="row"><b>Current Level ${S.level}</b><span class="pill">${S.lvUnlocked.length}/${MAXLV} unlocked</span></div><p style="margin-top:6px">${nx<=MAXLV?`Next level (${nx}) needs <b>${fmt(lvCost(nx))}</b> coins${S.coins<lvCost(nx)?` — you need ${fmt(lvCost(nx)-S.coins)} more`:' — you can unlock it now!'}`:'All levels unlocked 🎉'}</p><p>Higher levels = bigger numbers & harder questions.</p></div>
  ${Array.from({length:MAXLV},(_,i)=>i+1).map(l=>{const un=S.lvUnlocked.includes(l),can=l===nx;return `<div class="lvl glass ${l===S.level?'cur':''}" data-a="${un?'selLevel':'unlockLevel'}" data-p="${l}"><div class="n">${l}</div><div style="flex:1"><b>Level ${l}</b><br><small>${un?(l===S.level?'Selected':'Tap to select'):(can?'Next to unlock':'Locked')}</small></div>${un?'<span class="tag free">UNLOCKED</span>':`<span class="tag">🪙 ${fmt(lvCost(l))}</span>`}</div>`}).join('')}`};

/* spin */
let rot=0,spinning=false;
V.spin=()=>{rollDay();const sp=S.spin,free=CFG.freeSpins-sp.free;
  return `<div class="wheelbox"><div class="ptr">🔻</div><div id="wh"><canvas id="wc" width="600" height="600"></canvas></div><button class="hub" data-a="spin">SPIN</button></div>
  <div class="glass card" style="text-align:center" id="spinInfo">${spinInfo()}</div><button class="btn gold" id="spinBtn" data-a="spin">${spinLabel()}</button>`};
function spinInfo(){const sp=S.spin,free=CFG.freeSpins-sp.free;return `<b>Free spins left: ${free}/${CFG.freeSpins}</b><br><small>Ad spins used: ${sp.ad}/${CFG.adSpins} • Extra spins ready: ${sp.extra}</small>`}
function spinLabel(){const sp=S.spin;if(sp.free<CFG.freeSpins||sp.extra>0)return '🎡 SPIN';if(sp.ad<CFG.adSpins)return '📺 Watch Ad & Spin Again';return 'No spins left today'}
POST.spin=()=>{const c=$('#wc'),x=c.getContext('2d'),n=CFG.wheel.length,a=2*Math.PI/n,cols=['#7c3aed','#2f6bff','#00b8d9','#ffb400','#e11d8c'];
  for(let i=0;i<n;i++){x.beginPath();x.moveTo(300,300);x.arc(300,300,300,i*a-Math.PI/2,(i+1)*a-Math.PI/2);x.fillStyle=cols[i%5];x.fill();x.strokeStyle='rgba(255,255,255,.5)';x.lineWidth=3;x.stroke();
   x.save();x.translate(300,300);x.rotate(i*a+a/2);x.fillStyle='#fff';x.font='bold 40px sans-serif';x.textAlign='right';x.shadowColor='#000';x.shadowBlur=6;x.fillText(CFG.wheel[i][0],270,14);x.restore()}
  $('#wh').style.transform=`rotate(${rot}deg)`};
function rand01(){try{return crypto.getRandomValues(new Uint32Array(1))[0]/4294967296}catch(e){return Math.random()}}
function pickPrize(){const tot=CFG.wheel.reduce((s,w)=>s+w[1],0);let r=rand01()*tot;for(let i=0;i<CFG.wheel.length;i++){r-=CFG.wheel[i][1];if(r<0)return i}return 0}

/* ---------- actions ---------- */
const A={};
document.addEventListener('click',e=>{const el=e.target.closest('[data-a]');if(!el)return;if(el.classList.contains('dis'))return;if(!el.dataset.ns)sfx('click');const f=A[el.dataset.a];if(f)f(el.dataset.p,el)});
A.go=p=>go(p);A.back=()=>back();A.close=()=>{if(!S.pending)closeModal()};
A.toName=()=>go('name');
A.saveName=()=>{const v=($('#nm').value||'').trim().slice(0,16)||'Player';S.name=v;if(!S.onboarded){S.onboarded=1;save();addCoins(CFG.welcome,'Welcome Bonus');go('tut',0)}else{save();go('profile')}};
A.tutNext=p=>{p=+p;if(p>=TUT.length-1)go('home');else{cur='tut';param=p+1;render()}};A.tutSkip=()=>go('home');
A.editName=()=>go('name');
A.catSet=p=>{gameCat=p;render()};A.catGo=p=>{gameCat=p;go('games')};
A.taskCat=p=>{taskCat=+p;taskPage=1;render()};A.moreTasks=()=>{taskPage++;const y=$('#view').scrollTop;render();$('#view').scrollTop=y};
A.tog=k=>{S.set[k]=S.set[k]?0:1;save();if(k==='music')setMusic();render()};
A.theme=()=>{S.set.theme=S.set.theme==='dark'?'light':'dark';save();render()};
A.lang=()=>{S.set.lang=S.set.lang==='ur'?'en':'ur';save();render()};
A.resetAsk=()=>modal(`<div class="big">⚠️</div><h2>Reset Game Data?</h2><p style="margin:8px 0">All coins, levels, tasks and progress will be permanently deleted. This cannot be undone.</p><button class="btn" style="background:var(--no)" data-a="resetDo">Yes, delete everything</button><button class="btn ghost" data-a="close">Cancel</button>`);
A.resetDo=()=>{try{localStorage.removeItem('bb_state')}catch(e){}if(window.Android){try{Android.saveState('')}catch(e){}}S=def();closeModal();stack=[];setMusic();go('welcome',null,'replace')};
A.claimAch=id=>{const a=ACH.find(x=>x[0]===id);if(!a||S.claimed[id]||a[3]()<a[4])return;S.claimed[id]=1;addCoins(a[5],'Achievement: '+a[1]);sfx('coin');confetti();toast('Badge earned! +'+a[5]+' coins');render()};
A.claimDaily=()=>{const st=dailyState();if(st.claimed)return toast('Already claimed today');S.daily.streak=st.next;S.daily.last=dstr();addCoins(CFG.daily[st.idx],'Daily Reward (Day '+(st.idx+1)+')');sfx('win');confetti();toast('+'+CFG.daily[st.idx]+' coins!');render()};
A.adEarn=()=>{rollDay();if(S.adEarn.n>=CFG.adEarnLimit)return toast('Daily ad limit reached. Come back tomorrow!');watchAd(ok=>{if(ok){S.adEarn.n++;addCoins(CFG.adEarnCoins,'Rewarded Ad Bonus');sfx('coin');toast('+'+CFG.adEarnCoins+' coins!');if(cur==='rewards')render()}})};
A.selLevel=p=>{S.level=+p;save();toast('Level '+p+' selected');render()};
A.unlockLevel=p=>{p=+p;const hi=Math.max(...S.lvUnlocked);if(p!==hi+1)return toast('Unlock Level '+(hi+1)+' first');const c=lvCost(p);
  if(S.coins<c)return msgModal('🪙','Not Enough Coins!','Complete More Challenges To Earn Coins.');
  modal(`<div class="big">🔓</div><h2>Unlock Level ${p}?</h2><p>Required Coins: <b>${fmt(c)}</b><br>Your Coins: <b>${fmt(S.coins)}</b></p><button class="btn gold" data-a="doLevel" data-p="${p}">Unlock Level</button><button class="btn ghost" data-a="close">Cancel</button>`)};
A.doLevel=p=>{p=+p;const c=lvCost(p);if(S.lvUnlocked.includes(p)||!spend(c,'Level Unlock: '+p))return;S.lvUnlocked.push(p);S.level=p;save();closeModal();sfx('unlock');confetti();toast('Level '+p+' unlocked!');render()};

/* games: open / unlock */
A.openGame=p=>{const g=gameOf(+p);if(!S.gUnlocked.includes(g.id))return unlockModal(g.id);
  modal(`<div class="big">${g.i}</div><h2>${g.n}</h2><p style="margin:6px 0 10px">${g.desc}<br><small>Level ${S.level} • ${CFG.roundQ} questions</small></p>${DIFF.map((d,i)=>`<button class="btn ${i===3?'gold':''}" data-a="play" data-p="${g.id}:${i}">${d} <small style="color:inherit;opacity:.8">• ${CFG.perCorrect[i]} 🪙 / correct</small></button>`).join('')}<button class="btn ghost" data-a="close">Cancel</button>`)};
function unlockModal(id){const g=gameOf(id),pr=CFG.unlock[id];
  modal(`<div class="big">🔒</div><h2>Unlock This Game!</h2><h3>${g.i} ${g.n}</h3><p style="margin:10px 0">Required Coins: <b style="color:var(--gold)">${fmt(pr)}</b><br>Your Coins: <b>${fmt(S.coins)}</b></p><button class="btn gold" data-a="doUnlock" data-p="${id}">Unlock Game</button><button class="btn ghost" data-a="close">Cancel</button>`)}
A.doUnlock=p=>{p=+p;const pr=CFG.unlock[p];if(S.gUnlocked.includes(p))return closeModal();
  if(S.coins<pr)return msgModal('🪙','Not Enough Coins!','Complete More Challenges To Earn Coins.');
  if(!spend(pr,'Game Unlock: '+gameOf(p).n))return;S.gUnlocked.push(p);save();closeModal();sfx('unlock');confetti();toast(gameOf(p).n+' unlocked forever!');render()};
A.startTask=p=>{const t=TASKS[+p-1];if(S.done[t.id])return toast('Task already completed ✔');if(!S.gUnlocked.includes(t.gid))return unlockModal(t.gid);startGame(t.gid,t.d,t)};
A.play=p=>{const[a,b]=p.split(':').map(Number);closeModal();startGame(a,b,null)};

/* ---------- gameplay ---------- */
function startGame(gid,d,task){
  const gm=gameOf(gid);if(!S.gUnlocked.includes(gid))return unlockModal(gid);
  QB.level=S.level;G={gm,d,task,i:0,ok:0,bad:0,recent:[],t0:Date.now(),lock:true};closeModal();
  go('play',null,cur==='result'?'replace':undefined);nextQ();
}
V.play=()=>`<div class="play"><div class="ptop"><button class="ib" data-a="quit" data-ns="1">✕</button><div class="bar"><i id="pb"></i></div><b id="pc"></b></div><div class="tbar"><i id="tb"></i></div><div class="qcard glass"><small id="qm"></small><div id="qb"></div></div><div id="fb"></div><div id="ans"></div></div>`;
A.quit=()=>modal(`<div class="big">🚪</div><h2>Quit this round?</h2><p style="margin:8px 0">Your progress in this round will be lost.</p><button class="btn ghost" data-a="close">Keep playing</button><button class="btn" style="background:var(--no)" data-a="quitYes">Quit</button>`);
A.quitYes=()=>{closeModal();back()};
function nextQ(){
  if(!G)return;if(G.i>=CFG.roundQ)return finish();
  G.q=makeQ(G.gm,G.d,G.recent);G.lock=true;clearInterval(tick);
  if(!$('#qb'))render();
  const q=G.q;$('#pb').style.width=(G.i/CFG.roundQ*100)+'%';$('#pc').textContent=(G.i+1)+'/'+CFG.roundQ;
  $('#qm').textContent=`${G.gm.n} • ${DIFF[G.d]} • Lv ${S.level}${q.tag?' • '+q.tag:''}`;$('#fb').textContent='';$('#ans').innerHTML='';$('#tb').style.width='100%';
  if(q.k==='mem'||q.k==='flash'){
    $('#qb').innerHTML=`<p style="margin-top:12px">${q.k==='mem'?'Memorize this number':'Memorize these numbers'}</p><div class="show">${esc(q.show)}</div>`;
    setTimeout(()=>{if(G&&G.q===q)answerPhase(q)},q.ms);
  }else answerPhase(q);
}
function answerPhase(q){
  const sec=Math.round([15,12,9,7][G.d]*q.tmMul);G.lock=false;
  const long=q.q.length>22?' long':'';
  if(q.k==='mem'){$('#qb').innerHTML=`<h1 class="long">Type the number you saw</h1><input id="mi" class="inp" inputmode="numeric" autocomplete="off" maxlength="14"><button class="btn" data-a="subMem" data-ns="1">Submit</button>`;setTimeout(()=>{const i=$('#mi');if(i)i.focus()},50);return timer(Math.max(sec,12))}
  $('#qb').innerHTML=`<h1 class="${long}">${esc(q.q)}</h1>`;
  if(q.k==='grid')$('#ans').innerHTML=`<div class="gridn" style="grid-template-columns:repeat(${q.cols},1fr)">${q.cells.map((c,i)=>`<button class="opt" data-ns="1" data-a="pick" data-p="${i}">${c}</button>`).join('')}</div>`;
  else $('#ans').innerHTML=`<div class="opts ${q.o.length===2?'one':''}">${q.o.map((o,i)=>`<button class="opt" data-ns="1" data-a="pick" data-p="${i}">${esc(o)}</button>`).join('')}</div>`;
  timer(sec);
}
function timer(sec){const t0=performance.now(),tot=sec*1000,bar=$('#tb');clearInterval(tick);
  tick=setInterval(()=>{const r=1-(performance.now()-t0)/tot;if(bar)bar.style.width=Math.max(0,r*100)+'%';if(r<=0){clearInterval(tick);answer(null)}},100)}
A.pick=p=>answer(+p);
A.subMem=()=>answer(($('#mi')||{value:''}).value.trim());
function answer(v){
  if(!G||G.lock)return;G.lock=true;clearInterval(tick);const q=G.q;let ok;
  if(q.k==='mem')ok=v===q.a;else ok=v===q.a;
  const btns=document.querySelectorAll('#ans .opt');
  if(q.k!=='mem'&&btns.length){btns[q.a].classList.add('ok');if(!ok&&v!==null)btns[v].classList.add('no')}
  if(ok){G.ok++;sfx('ok');buzz(20);$('#fb').innerHTML=`<span class="plus">✔ Correct! +${10*(G.d+1)} pts</span>`}
  else{G.bad++;sfx('bad');buzz([60,40,60]);const c=q.k==='mem'?q.a:q.k==='grid'?q.cells[q.a]:q.o[q.a];$('#fb').innerHTML=`<span class="minus">${v===null?'⏱ Time up!':'✘ Wrong!'} Answer: ${esc(c)}</span>`}
  G.i++;setTimeout(nextQ,ok?750:1300);
}
function finish(){
  clearInterval(tick);const ok=G.ok,bad=G.bad,pts=ok*10*(G.d+1),coins=ok*CFG.perCorrect[G.d],sec=Math.round((Date.now()-G.t0)/1000);rollDay();
  const st=S.stats;st.played++;st.correct+=ok;st.wrong+=bad;st.sec+=sec;st.best=Math.max(st.best,pts);S.xp+=pts;S.today.games++;
  const pg=S.pg[G.gm.id]||(S.pg[G.gm.id]={p:0,c:0,w:0});pg.p++;pg.c+=ok;pg.w+=bad;
  if(coins>0)addCoins(coins,'Game: '+G.gm.n);
  let tdone=false;
  if(G.task&&!S.done[G.task.id]&&ok>=G.task.target){S.done[G.task.id]=1;st.tasks++;S.pending={id:G.task.id,reward:G.task.reward};tdone=true}
  save();G.res={ok,bad,pts,coins,tdone,task:G.task};go('result',null,'replace');
  if(ok>=7||tdone){sfx('win');confetti()}
}
V.result=()=>{const r=G&&G.res;if(!r)return '<div class="full"><button class="btn" data-a="go" data-p="home">Home</button></div>';
  const pc=Math.round(r.ok/CFG.roundQ*100),msg=pc>=90?'Brilliant! 🌟':pc>=70?'Great job! 🎉':pc>=50?'Good effort! 💪':'Keep practicing! 📚';
  return `<div class="res"><h2 style="margin-top:6px">${msg}</h2><div class="ring" style="--p:${pc}" data-t="${r.ok}/${CFG.roundQ}"></div>
  <div class="stats"><div class="stat glass"><b class="plus">${r.ok}</b><small>Correct</small></div><div class="stat glass"><b class="minus">${r.bad}</b><small>Wrong</small></div><div class="stat glass"><b>${r.pts}</b><small>Points</small></div><div class="stat glass"><b>🪙 ${r.coins}</b><small>Coins earned</small></div></div>
  ${G.task&&!r.tdone&&!S.done[G.task.id]?`<p class="glass card">Task needs ${G.task.target}/${CFG.roundQ} correct — try again!</p>`:''}
  <button class="btn" data-a="again">🔄 Play Again</button><button class="btn gold" data-a="nextGame">Next Game ▶</button><button class="btn ghost" data-a="go" data-p="home">Home</button></div>`};
A.again=()=>startGame(G.gm.id,G.d,G.task&&!S.done[G.task.id]?G.task:null);
A.nextGame=()=>{const un=GAMES.filter(g=>S.gUnlocked.includes(g.id)),i=un.findIndex(g=>g.id===G.gm.id),n=un[(i+1)%un.length];startGame(n.id,G.d,null)};

/* task reward: collect or double (double only after verified native rewarded-ad callback) */
function taskModal(){const p=S.pending;if(!p)return;
  modal(`<div class="big">🏆</div><h2>CONGRATULATIONS!</h2><p style="margin:6px 0">Task Completed Successfully!</p><h3>You Earned <span style="color:var(--gold)">${p.reward}</span> Coins.</h3>
  <button class="btn gold" data-a="collect">Collect ${p.reward} Coins</button><button class="btn" data-a="doubleAd">📺 Watch Ad & Double Your Coins</button>`)}
A.collect=()=>{const p=S.pending;if(!p||pendingAd)return;S.pending=null;addCoins(p.reward,'Task Completed: #'+p.id);sfx('coin');closeModal();toast('+'+p.reward+' coins collected!');syncCoin()};
A.doubleAd=()=>{const p=S.pending;if(!p||pendingAd)return;const id=p.id;
  watchAd(ok=>{const q=S.pending;if(!ok||!q||q.id!==id)return;S.pending=null;addCoins(q.reward*2,'Double Reward: Task #'+id);sfx('coin');closeModal();toast('Doubled! +'+q.reward*2+' coins');syncCoin()})};

/* spin logic */
A.spin=()=>{
  if(spinning||cur!=='spin')return;rollDay();const sp=S.spin;
  if(sp.free<CFG.freeSpins)sp.free++;
  else if(sp.extra>0)sp.extra--;
  else if(sp.ad<CFG.adSpins){
    return modal(`<div class="big">🎡</div><h2>Free Spins Completed!</h2><p style="margin:8px 0">Watch a Rewarded Ad to Unlock One More Spin.</p><small>${CFG.adSpins-sp.ad} ad spins left today</small><button class="btn gold" data-a="spinAd">Watch Ad & Spin Again</button><button class="btn ghost" data-a="close">Not now</button>`);
  }else return toast('No spins left today. Come back tomorrow!');
  const i=pickPrize(),n=CFG.wheel.length,seg=360/n,coins=CFG.wheel[i][0];
  addCoins(coins,'Lucky Spin');spinning=true;
  const target=(360-(i*seg+seg/2)+(rand01()-.5)*seg*.7+360)%360,cu=((rot%360)+360)%360;
  rot+=360*6+((target-cu)+360)%360;$('#wh').style.transform=`rotate(${rot}deg)`;$('#spinBtn').classList.add('dis');
  let k=0;const tk=setInterval(()=>{sfx('tick');if(++k>22)clearInterval(tk)},200);
  setTimeout(()=>{spinning=false;sfx('win');confetti();buzz(80);if(cur==='spin'){$('#spinInfo').innerHTML=spinInfo();$('#spinBtn').textContent=spinLabel();$('#spinBtn').classList.remove('dis')}
    modal(`<div class="big">🎉</div><h2>You won ${coins} coins!</h2><button class="btn gold" data-a="close">Awesome</button>`)},4700);
};
A.spinAd=()=>{closeModal();rollDay();if(S.spin.ad>=CFG.adSpins)return;watchAd(ok=>{if(ok){S.spin.ad++;S.spin.extra++;save();if(cur==='spin')A.spin()}})};

/* ---------- boot ---------- */
function boot(){
  load();rollDay();setMusic();
  setTimeout(()=>{const sp=$('#splash');sp.style.opacity=0;setTimeout(()=>sp.remove(),500);go(S.onboarded?'home':'welcome',null,'replace')},1800);
}
boot();
