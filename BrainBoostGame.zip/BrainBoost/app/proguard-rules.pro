-keepclassmembers class com.brainboost.game.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
